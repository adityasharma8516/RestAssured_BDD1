package test;

import consts.UrlParamValues;
import io.restassured.RestAssured;
import io.restassured.specification.RequestSpecification;
import org.junit.jupiter.api.BeforeAll;

import java.util.Map;

public class BaseTest {
    @BeforeAll
    public static void setBaseUrl(){
        RestAssured.baseURI="https://api.trello.com";
    }
    protected static RequestSpecification requestWithAuth() {
        return requestWithoutAuth()
/*                .queryParam(Map.of(
                        "key", "99b0cd1ae01f0d163c0ada8ed25c6f3c",
                        "token", "ATTA18b63075f7cdd4d8ded4e2b4d1ba2ed28932b97ef1e5edfaa5f5d233796f481c51AF7C80").toString());*/
                .queryParams(UrlParamValues.AUTH_QUERY_PARAMS);
    }

    protected static RequestSpecification requestWithoutAuth() {
        return RestAssured.given();
    }
}
