package test.get;

import consts.BoardsEndpoints;
import consts.UrlParamValues;
import test.BaseTest;
import io.restassured.module.jsv.JsonSchemaValidator;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.Test;

public class GetBoardTest extends BaseTest {
/*    @BeforeAll
    public static void setBaseUrl(){
        RestAssured.baseURI="https://api.trello.com";
    }*/
/*    private static RequestSpecification requestWithAuth() {
        return RestAssured.given()
                .queryParam(Map.of(
                        "key", "99b0cd1ae01f0d163c0ada8ed25c6f3c",
                        "token", "ATTA18b63075f7cdd4d8ded4e2b4d1ba2ed28932b97ef1e5edfaa5f5d233796f481c51AF7C80").toString());
    }*/
    @Test
    public void checkGetBoards(){
        requestWithAuth()
                .queryParam("fields","id,name")
                .pathParam("member", UrlParamValues.USER_NAME)
                .get(BoardsEndpoints.GET_ALL_BOARDS_URL)
              //  .prettyPeek()
                .then()
                .statusCode(200)
                .body(JsonSchemaValidator.matchesJsonSchemaInClasspath("schemas/get_boards.json"));
    }

    @Test
    public void checkGetBoard(){
        requestWithAuth()
                .queryParam("fields","id,name")
                .pathParam("id", UrlParamValues.EXISTING_BOARD_ID)
                .get(BoardsEndpoints.GET_BOARD_URL)
                .then()
                .statusCode(200)
                .body("name", Matchers.equalTo("restBoard"))
                .body(JsonSchemaValidator.matchesJsonSchemaInClasspath("schemas/get_board.json"));
    }
}
