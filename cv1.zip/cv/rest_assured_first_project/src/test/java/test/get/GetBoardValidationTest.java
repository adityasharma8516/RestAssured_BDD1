package test.get;

import arguments.holders.AuthValidationArgumentsHolder;
import arguments.providers.AuthValidationArgumentsProvider;
import arguments.holders.BoardIdValidationArgumentHolder;
import arguments.providers.BoardIdValidationArgumentProvider;
import consts.BoardsEndpoints;
import consts.UrlParamValues;
import test.BaseTest;
import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.response.Response;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ArgumentsSource;

import java.util.Map;

public class GetBoardValidationTest extends BaseTest {
/*    @BeforeAll
    public static void setBaseUrl(){
        RestAssured.baseURI="https://api.trello.com";
    }*/
/*    private static RequestSpecification requestWithAuth() {
        return RestAssured.given()
                .queryParam(Map.of(
                        "key", "99b0cd1ae01f0d163c0ada8ed25c6f3c",
                        "token", "ATTA18b63075f7cdd4d8ded4e2b4d1ba2ed28932b97ef1e5edfaa5f5d233796f481c51AF7C80").toString());
    }*/
    /*@Test
    public void checkGetBoardWithInvalidId(){
        Response response = requestWithAuth()
                .pathParam("id", "invalid")
                .get("/1/boards/{id}");
        response
                .then()
                .statusCode(400);
        Assertions.assertEquals("invalid id", response.body().asString());
    }*/
    @ParameterizedTest
    @ArgumentsSource(BoardIdValidationArgumentProvider.class)
    public void checkGetBoardWithInvalidId(BoardIdValidationArgumentHolder ValidationArguments){
        Response response = requestWithAuth()
                .pathParams(ValidationArguments.getPathParams())
                .get(BoardsEndpoints.GET_BOARD_URL);
        response
                .then()
                .statusCode(ValidationArguments.getStatusCode());
        Assertions.assertEquals(ValidationArguments.getErrorMessage(), response.body().asString());
    }

/*    @Test
    public void checkGetBoardWithInvalidAuth(){
        Response response = requestWithoutAuth()
                .pathParam("id", "abcd1234")
                .get("/1/boards/{id}");
        response
                .then()
                .statusCode(404);
        Assertions.assertEquals("Board not found", response.body().asString());
    }*/
    @ParameterizedTest
    @ArgumentsSource(AuthValidationArgumentsProvider.class)
    public void checkGetBoardWithInvalidAuth(AuthValidationArgumentsHolder validationArguments){
        Response response = requestWithoutAuth()
                .queryParams(validationArguments.getAuthParams())
                .pathParam("id", UrlParamValues.WRONG_BOARD_ID)
                .get(BoardsEndpoints.GET_BOARD_URL);
        response
                .then()
//                .statusCode(404);
//        Assertions.assertEquals("Board not found", response.body().asString());
                .statusCode(401);
        Assertions.assertEquals("invalid key", response.body().asString());
    }

    @Test
    public void checkGetBoardWithAnotherUserCredentials(){
        Response response = requestWithoutAuth()
                .queryParam(UrlParamValues.ANOTHER_USER_AUTH_QUERY.toString())
                .pathParam("id", UrlParamValues.WRONG_BOARD_ID)
                .get(BoardsEndpoints.GET_BOARD_URL);
        response
                .then()
                .statusCode(404);
        Assertions.assertEquals("Board not found", response.body().asString());
    }
    @Test
    public void checkGetBoards(){
        requestWithAuth()
                .queryParam("fields","id,name")
                .pathParam("member", UrlParamValues.USER_NAME)
                .get(BoardsEndpoints.GET_ALL_BOARDS_URL)
              //  .prettyPeek()
                .then()
                .statusCode(200)
                .body(JsonSchemaValidator.matchesJsonSchemaInClasspath("schemas/get_boards.json"));
    }

    @Test
    public void checkGetBoard(){
        requestWithAuth()
                .queryParam("fields","id,name")
                .pathParam("id", UrlParamValues.EXISTING_BOARD_ID)
                .get(BoardsEndpoints.GET_BOARD_URL)
                .then()
                .statusCode(200)
                .body("name", Matchers.equalTo("restBoard"))
                .body(JsonSchemaValidator.matchesJsonSchemaInClasspath("schemas/get_board.json"));
    }
}
