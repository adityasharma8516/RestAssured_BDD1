package test.get;

import test.BaseTest;
import io.restassured.module.jsv.JsonSchemaValidator;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.Test;

public class GetCardsTest extends BaseTest {
/*    @BeforeAll
    public static void setBaseUrl(){
        RestAssured.baseURI="https://api.trello.com";
    }*/

/*    private static RequestSpecification requestWithAuth() {
        return RestAssured.given()
                .queryParam(Map.of(
                        "key", "99b0cd1ae01f0d163c0ada8ed25c6f3c",
                        "token", "ATTA18b63075f7cdd4d8ded4e2b4d1ba2ed28932b97ef1e5edfaa5f5d233796f481c51AF7C80").toString());
    }*/
/*    @Test
    public void checkGetCards(){
        requestWithAuth()
                .pathParam("list_id", "6722f1468ec0b3d65a5ced20")
                .get("/1/lists/{list_id}/cards")
                .then()
                .statusCode(200)
                .body(JsonSchemaValidator.matchesJsonSchemaInClasspath("schemas/get_cards.json"));
    }

    @Test
    public void checkGetCard(){
        requestWithAuth()
                .pathParam("id", "6722f12f469ee278faf79595")
                .get("/1/cards/{id}")
                .then()
                .statusCode(200)
                .body("name", Matchers.equalTo("Hi1"))
                .body(JsonSchemaValidator.matchesJsonSchemaInClasspath("schemas/get_card.json"));
    }*/
}
