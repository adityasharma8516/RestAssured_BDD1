package steps;

import consts.Endpoint;
import consts.UrlParamValues;
import io.cucumber.core.options.CurlOption;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.Assertions;
import utils.RestRequestProvider;



import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TrelloApiActionSteps {
    private final ScenarioContext scenarioContext;

    public TrelloApiActionSteps(ScenarioContext scenarioContext) {
        this.scenarioContext = scenarioContext;
    }

/*    private static RequestSpecification requestWithAuth() {
        return requestWithoutAuth()
*//*                .queryParam(Map.of(
                        "key", "99b0cd1ae01f0d163c0ada8ed25c6f3c",
                        "token", "ATTA18b63075f7cdd4d8ded4e2b4d1ba2ed28932b97ef1e5edfaa5f5d233796f481c51AF7C80").toString());*//*
                .queryParams(UrlParamValues.AUTH_QUERY_PARAMS);
    }

    private static RequestSpecification requestWithoutAuth() {
        RestAssured.baseURI = "https://api.trello.com";
        return RestAssured.given();
    }*/
    @Given("a request {with} authorization")
    public void aRequestWithAuthorization(boolean withAuth) {
        scenarioContext.setRequest(withAuth? RestRequestProvider.requestWithAuth(): RestRequestProvider.requestWithoutAuth());
    }
/*
    @Given("a request without authorization")
    public void aRequestWithoutAuthorization() {
        scenarioContext.setRequest(requestWithoutAuth());
    }
*/

    @Given("the request has query params:")
    public void theRequestHasQueryParam(DataTable dataTable) {
//        request = request.queryParam("fields","id,name");
        Map<String, String> queryParams = dataTable.asMap();
//        request = request.queryParam(paramName, paramValue);
        scenarioContext.setRequest(scenarioContext.getRequest().queryParams(queryParams));
    }
    @And("the request has body params:")
    public void theRequestHasBodyParam(DataTable dataTable) {
        scenarioContext.setRequest(scenarioContext.getRequest().body(dataTable.asMap()));
    }
    @And("the request has headers:")
    public void thrRequestHasHeader(DataTable dataTable) {
        scenarioContext.setRequest(scenarioContext.getRequest().headers(dataTable.asMap()));
    }

    @Given("the request has path params:")
    public void theRequestHasPathParam(DataTable dataTable) {
        Map<String, String> pathParams = new HashMap<>();
        List<Map<String, String>> rows = dataTable.asMaps();
        for (Map<String, String> row:rows){
            String rowValue = row.get("value");
            String value = rowValue.equals("created_board_id")?scenarioContext.getBoardId():rowValue;
            pathParams.put(row.get("name"), value);
        }
        scenarioContext.setRequest(scenarioContext.getRequest().pathParams(pathParams));
    }
    @When("the '{}' request is sent to '{endpoint}' endpoint")
    public void theRequestIsSentToEndpoint(CurlOption.HttpMethod method, Endpoint endpoint) {
        String url = endpoint.getUrl();
        switch (method) {
            case GET ->  scenarioContext.setResponse(scenarioContext.getRequest().get(url));
            case PUT ->  scenarioContext.setResponse(scenarioContext.getRequest().put(url));
            case POST -> scenarioContext.setResponse(scenarioContext.getRequest().post(url));
            case DELETE -> scenarioContext.setResponse(scenarioContext.getRequest().delete(url));
            default -> throw new RuntimeException();
        }
    }

    @When("the board ID from the response is remembered")
    public void theBoardIdFromTheResponseIsRemembered() {
        String createdBoardId = scenarioContext.getResponse().body()
                .jsonPath().getString("id");
        scenarioContext.setBoardId(createdBoardId);
    }
}
