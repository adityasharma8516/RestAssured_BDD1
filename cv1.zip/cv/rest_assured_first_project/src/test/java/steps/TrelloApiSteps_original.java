package steps;

import consts.BoardsEndpoints;
import consts.UrlParamValues;
import io.cucumber.core.options.CurlOption;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.Assertions;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TrelloApiSteps_original
{

///*
//    private RequestSpecification request;
//    private Response response;
//    private static RequestSpecification requestWithAuth() {
//        return requestWithoutAuth()
//*/
///*                .queryParam(Map.of(
//                        "key", "99b0cd1ae01f0d163c0ada8ed25c6f3c",
//                        "token", "ATTA18b63075f7cdd4d8ded4e2b4d1ba2ed28932b97ef1e5edfaa5f5d233796f481c51AF7C80").toString());*//*
//
//                .queryParams(UrlParamValues.AUTH_QUERY_PARAMS);
//    }
//
//    private static RequestSpecification requestWithoutAuth() {
//        RestAssured.baseURI = "https://api.trello.com";
//        return RestAssured.given();
//    }
//    @Given("a request with authorization")
//    public void aRequestWithAuthorization() {
//        request = requestWithAuth();
//    }
//    @Given("a request without authorization")
//    public void aRequestWithoutAuthorization() {
//        request = requestWithoutAuth();
//    }
//
//    @Given("the request has query params:")
//    public void theRequestHasQueryParam(DataTable dataTable) {
////        request = request.queryParam("fields","id,name");
//        Map<String, String> queryParams = dataTable.asMap();
////        request = request.queryParam(paramName, paramValue);
//        request = request.queryParams(queryParams);
//    }
//    @And("the request has body params:")
//    public void theRequestHasBodyParam(DataTable dataTable) {
//        request = request.body(dataTable.asMap());
////        request = request.body(Map.of(bodyParam, value));
//    }
//    @And("the request has headers:")
//    public void thrRequestHasHeader(DataTable dataTable) {
//        request = request.headers(dataTable.asMap());
////        request = request.header(headerName, value);
//    }
//
//    @Given("the request has path params:")
//    public void theRequestHasPathParam(DataTable dataTable) {
//        Map<String, String> pathParams = new HashMap<>();
//        List<Map<String, String>> rows = dataTable.asMaps();
//        for (Map<String, String> row:rows){
//            pathParams.put(row.get("name"), row.get("value"));
//        }
////        request = request.pathParam("member", UrlParamValues.USER_NAME);
//        request = request.pathParams(pathParams);
//    }
//    @When("the '{}' request is sent to {string} endpoint")
//    public void theRequestIsSentToEndpoint(CurlOption.HttpMethod method, String endpoint) {
//        switch (method) {
//            case GET ->  response = request.get(endpoint);
//            case PUT ->  response = request.put(endpoint);
//            case POST -> response = request.post(endpoint);
//            case DELETE -> response = request.delete(endpoint);
//            default -> throw new RuntimeException();
//        }
//    }
////    @And("the request has ID path param")
////    public void theRequestHasIdPathParam() {
////        request = request.pathParam("id", UrlParamValues.EXISTING_BOARD_ID);
////    }
//
//*/
///*    @When("the request is sent to getBoards endpoint")
//    public void theRequestIsSentToGetBoardsEndpoint() {
//        response = request.get(BoardsEndpoints.GET_ALL_BOARDS_URL);
//    }
//    @When("the request is sent to getBoard endpoint")
//    public void theRequestIsSentToGetBoardEndpoint() {
//        response = request.get(BoardsEndpoints.GET_BOARD_URL);
//    }*//*
//

}
