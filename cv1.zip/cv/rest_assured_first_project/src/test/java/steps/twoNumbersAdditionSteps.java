package steps;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Assertions;

public class twoNumbersAdditionSteps {
    private int numberOne;
    private int numberTwo;
    private int result;

    @Given("user has number one as {int}")
    public void userHasNumberOneAs(int arg0) {
        numberOne = 10;
    }

    @Given("user has number two as {int}")
    public void userHasNumberTwoAs(int arg0) {
        numberTwo = 20;
    }

    @When("user adds number one and number two")
    public void userAddsNumberOneAndNumberTwo() {
        result = numberOne + numberTwo;
    }

    @Then("the result is {int}")
    public void theResultIs(int arg0) {
        Assertions.assertEquals(result, 30);
    }
}
