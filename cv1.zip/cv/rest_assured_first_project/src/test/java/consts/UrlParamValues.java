package consts;

import java.util.Map;

public class UrlParamValues {
    public static final String EXISTING_BOARD_ID = "6722ecee422563c3d1aa743e";
    public static final String WRONG_BOARD_ID = "abcd1234";
    public static final String USER_NAME = "aditya488";
    public static final String VALID_KEY = "99b0cd1ae01f0d163c0ada8ed25c6f3c";
    public static final String VALID_TOKEN = "ATTA18b63075f7cdd4d8ded4e2b4d1ba2ed28932b97ef1e5edfaa5f5d233796f481c51AF7C80";
    public static final Map<String, String> AUTH_QUERY_PARAMS = Map.of(
            "key", VALID_KEY,
            "token", VALID_TOKEN);

    public static final Map<String, String> ANOTHER_USER_AUTH_QUERY = Map.of(
            "key", "abcd1234",
            "token", "abcd1234");
    public static final Map<String, String> ANOTHER_USER_AUTH_QUERY_PARAMS = Map.of(
            "key", "8b32218e6887516d17c84253faf967b6",
            "token", "492343b8106e7df3ebb7f01e219cbf32827c852a5f9e2b8f9ca296b1cc604955"
    );


    public static final String EXISTING_CARD_ID = "6722ecee422563c3d1aa743e";
    public static final String EXISTING_LIST_ID = "60d84769c4ce7a09f9140221";
    public static final String BOARD_ID_TO_UPDATE = "6728feba663650aeec35a670";
}
