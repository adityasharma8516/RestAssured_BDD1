package arguments.providers;

import arguments.holders.BoardIdValidationArgumentHolder;
import org.junit.jupiter.api.extension.ExtensionContext;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.ArgumentsProvider;

import java.util.Map;
import java.util.stream.Stream;

public class BoardIdValidationArgumentProvider implements ArgumentsProvider {

    @Override
    public Stream provideArguments(ExtensionContext context) {
        return Stream.of(
                new BoardIdValidationArgumentHolder(
                        Map.of("id","invalid"),
                        "invalid id",
                        400
                ),
                new BoardIdValidationArgumentHolder(
                        Map.of("id","abcd1234"),
                        "Board not found",
                        404
                )
        ).map(Arguments::of);
    }
}
