package arguments.holders;

import java.util.Map;

public class CardBodyValidationArgumentsHolder {

    private final Map<String, String> bodyParams;

    private final String errorMessage;

    public CardBodyValidationArgumentsHolder(Map<String, String> bodyParams, String errorMessage) {
        this.bodyParams = bodyParams;
        this.errorMessage = errorMessage;
    }

    public Map<String, String> getBodyParams() {
        return bodyParams;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

}